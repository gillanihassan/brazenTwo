import React from "react";
import styles from "./styles.module.css";
import { Image } from "react-bootstrap";
import brazenBackground from "../../../assets/images/brazenbakground/brazanBackground.png";

export default function HeroSection() {
  return (
    <div className={`${styles.heroContainer}`}>
      <Image src={brazenBackground} className={`${styles.heroBg}`} />

      <div className={styles.overlay} />

      {/* Navbar */}
      <div className="position-absolute top-0 start-0 end-0 p-4 d-flex justify-content-between align-items-center text-white z-3">
        <h1 className="fs-4 fw-bold m-0">Project Brazen</h1>
        <nav className="d-flex gap-5">
          <a href="#" className={`text-decoration-none ${styles.customLink}`}>
            About
          </a>
          <a href="#" className={`text-decoration-none ${styles.customLink}`}>
            Projects
          </a>
          <a href="#" className={`text-decoration-none ${styles.customLink}`}>
            Shop
          </a>
          <a href="#" className={`text-decoration-none ${styles.customLink}`}>
            Contact
          </a>
          <a href="#" className={`text-decoration-none ${styles.customLink}`}>
            Brazen
          </a>
        </nav>
      </div>
    </div>
  );
}
