import React from "react";
import styles from "./styles.module.css";
import { Container } from "react-bootstrap";

export default function Media() {
  return (
    <Container className={`pb-5 ${styles.mainDiv}`}>
      <h1 className={`${styles.customHeading}`}>
        Discovering new worlds<span className="text-danger">.</span>
      </h1>

      <div className={` ${styles.customDiv}`}>
        <div>
          <div className="mb-0">LDN</div>
          <div className="">13:54</div>
        </div>
        <div>
          <div className="mb-0">NYC</div>
          <div className="">8:54</div>
        </div>
        <div>
          <div className="mb-0">SG</div>
          <div className="">21:54</div>
        </div>
      </div>

      <p className={` ${styles.customPara}`}>
        From page to screen,{" "}
        <span className="fw-bold text-danger">we craft stories</span> <br />{" "}
        that shape culture and uncover <br /> hidden worlds. Film, television,
        books, <br /> documentaries, podcasts — our work <br /> pushes
        boundaries and ignites <br /> conversations around the globe
        <span className="text-danger">.</span>
      </p>
    </Container>
  );
}
