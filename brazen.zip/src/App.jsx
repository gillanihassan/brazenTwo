import "./App.css";
import Brazen from "./pages/brazen/Brazen";

function App() {
  return (
    <>
      <Brazen />
    </>
  );
}

export default App;
